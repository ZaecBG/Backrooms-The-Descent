package com.carter.backrooms;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.VertexAttributes;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Disposable;
import java.util.Random;

/** A real polygonal 3D first-person Android game. All world geometry is rendered by libGDX ModelBatch. */
public class DescentGame extends ApplicationAdapter implements InputProcessor {
    private static final int N = 21;
    private static final float CELL = 3f;
    private static final int REQUIRED = 3;
    private enum State { TITLE, PLAYING, PAUSED, CAUGHT, COMPLETE }
    private State state = State.TITLE;

    private PerspectiveCamera camera;
    private ModelBatch modelBatch;
    private Environment environment;
    private ModelBuilder builder;
    private SpriteBatch uiBatch;
    private ShapeRenderer shapes;
    private BitmapFont font;
    private final Array<Model> models = new Array<>();
    private final Array<Texture> textures = new Array<>();
    private final Array<ModelInstance> world = new Array<>();
    private final Array<Pickup> pickups = new Array<>();
    private Model floorModel, wallModel, ceilingModel, trimModel, propModel, orbModel, monsterBody, monsterHead, monsterLimb, lightModel;
    private ModelInstance monsterBodyI, monsterHeadI, monsterArmLI, monsterArmRI, monsterLegLI, monsterLegRI;
    private boolean[][] solid = new boolean[N][N];
    private int level = 0, collected = 0;
    private float px = 3f, pz = 3f, yaw = 0f, pitch = 0f;
    private float monsterX = 52.5f, monsterZ = 52.5f, monsterSpeed = 1.5f;
    private float stamina = 1f, fear = 0f, elapsed = 0f, damageFlash = 0f, bob = 0f;
    private boolean sprint = false, flashlight = true, soundOn = true;
    private float joystickX, joystickY, lookDX, lookDY;
    private int movePointer = -1, lookPointer = -1, sprintPointer = -1;
    private float moveOriginX, moveOriginY, lookLastX, lookLastY;
    private final Vector3 tmp = new Vector3();
    private Color levelFloor = new Color(0.30f,0.28f,0.20f,1), levelWall = new Color(0.70f,0.65f,0.42f,1), levelTrim = new Color(0.42f,0.36f,0.22f,1);
    private String levelName = "HABITUAL ROOMS";
    private final String[] names = {"HABITUAL ROOMS","THE SERVICE TUNNELS","FLOODED ARCHIVE","ABANDONED HOTEL","ELECTRICAL MAZE","THE PIPEWORKS","INFINITE OFFICES","THE RED EXIT","SUBLEVEL 9","THE LAST ROOM"};
    private final Color[] palettes = {
        new Color(.68f,.62f,.40f,1), new Color(.30f,.37f,.36f,1), new Color(.20f,.34f,.39f,1), new Color(.42f,.34f,.30f,1), new Color(.34f,.32f,.22f,1),
        new Color(.29f,.36f,.31f,1), new Color(.46f,.47f,.42f,1), new Color(.46f,.16f,.14f,1), new Color(.20f,.19f,.24f,1), new Color(.55f,.49f,.43f,1)
    };

    @Override public void create() {
        modelBatch = new ModelBatch(); uiBatch = new SpriteBatch(); shapes = new ShapeRenderer(); font = new BitmapFont(); font.getData().setScale(1.05f);
        builder = new ModelBuilder();
        camera = new PerspectiveCamera(74, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        camera.near = .08f; camera.far = 48f; camera.position.set(px,1.68f,pz); camera.direction.set(0,0,-1); camera.up.set(Vector3.Y);
        environment = new Environment(); environment.set(new ColorAttribute(ColorAttribute.AmbientLight, .34f,.32f,.25f,1));
        environment.add(new DirectionalLight().set(.58f,.55f,.43f,-.4f,-1f,-.25f));
        buildModels(); Gdx.input.setInputProcessor(this); Gdx.input.setCatchKey(Input.Keys.BACK,true);
    }

    private Model makeBox(float w,float h,float d,Color c) {
        Material m = new Material(ColorAttribute.createDiffuse(c));
        Model model = builder.createBox(w,h,d,m, VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        models.add(model); return model;
    }
    private Model makeSphere(float size, Color c) {
        Model model = builder.createSphere(size,size,size,16,12,new Material(ColorAttribute.createDiffuse(c)), VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal);
        models.add(model); return model;
    }
    // Small generated tileable textures keep the APK self-contained while giving surfaces real detail.
    private Texture makePattern(Color base, int kind) {
        final int size = 128;
        Pixmap pix = new Pixmap(size, size, Pixmap.Format.RGBA8888);
        Random noise = new Random(4401L + kind * 991L);
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                float n = (noise.nextFloat() - .5f) * (kind == 0 ? .13f : .10f);
                float shade = 1f + n;
                if (kind == 0) {
                    // Faded yellow wallpaper: vertical joins, subtle stains and scuffs.
                    if (x % 32 < 2) shade *= .72f;
                    if ((x + y * 3) % 97 < 2) shade *= .78f;
                    int dx = (x % 43) - 21, dy = (y % 37) - 18;
                    if (dx * dx + dy * dy < 13) shade *= .82f;
                } else if (kind == 1) {
                    // Concrete floor: large worn square tiles and grout seams.
                    if (x % 32 < 2 || y % 32 < 2) shade *= .62f;
                    if ((x * 7 + y * 11) % 131 < 3) shade *= .78f;
                } else if (kind == 2) {
                    // Dark ceiling panels and metal seams.
                    if (x % 32 < 3 || y % 32 < 3) shade *= .58f;
                    if ((x + y) % 61 < 2) shade *= .8f;
                } else {
                    // Grimy painted metal for props and trim.
                    if (x % 24 < 2) shade *= .72f;
                }
                pix.setColor(MathUtils.clamp(base.r * shade, 0, 1),
                             MathUtils.clamp(base.g * shade, 0, 1),
                             MathUtils.clamp(base.b * shade, 0, 1), 1f);
                pix.drawPixel(x, y);
            }
        }
        Texture texture = new Texture(pix);
        texture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        texture.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat);
        pix.dispose();
        textures.add(texture);
        return texture;
    }

    private Model makeTexturedBox(float w, float h, float d, Color base, int pattern) {
        Texture texture = makePattern(base, pattern);
        Material material = new Material(TextureAttribute.createDiffuse(texture),
                                         ColorAttribute.createDiffuse(Color.WHITE));
        Model model = builder.createBox(w, h, d, material,
                VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal | VertexAttributes.Usage.TextureCoordinates);
        models.add(model);
        return model;
    }

    private void buildModels() {
        floorModel=makeTexturedBox(CELL,.16f,CELL,new Color(.37f,.34f,.27f,1),1);
        wallModel=makeTexturedBox(CELL,3.6f,CELL,new Color(.78f,.72f,.49f,1),0);
        ceilingModel=makeTexturedBox(CELL,.16f,CELL,new Color(.31f,.30f,.27f,1),2);
        trimModel=makeTexturedBox(CELL,.13f,.28f,new Color(.28f,.25f,.19f,1),3);
        propModel=makeTexturedBox(.65f,1.2f,.65f,new Color(.30f,.29f,.25f,1),3);
        lightModel=makeBox(1.25f,.07f,.55f,new Color(.92f,.88f,.70f,1));
        orbModel=makeSphere(.55f,new Color(.45f,.92f,.72f,1));
        monsterBody=makeSphere(1.35f,new Color(.025f,.03f,.035f,1)); monsterHead=makeSphere(.82f,new Color(.008f,.012f,.016f,1)); monsterLimb=makeSphere(.58f,new Color(.018f,.022f,.027f,1));
    }

    private void add(Model m,float x,float y,float z,float sx,float sy,float sz) {
        ModelInstance i=new ModelInstance(m); i.transform.setToTranslation(x,y,z).scale(sx,sy,sz); world.add(i);
    }
    private void clearWorld() { world.clear(); pickups.clear(); }
    private void generateLevel(int index) {
        clearWorld(); level=index; levelName=names[index]; levelWall=palettes[index]; levelFloor=palettes[index].cpy().mul(.53f); levelTrim=palettes[index].cpy().mul(.62f);
        Random r=new Random(9137L+index*7919L);
        for(int z=0;z<N;z++) for(int x=0;x<N;x++) solid[x][z]=true;
        // Randomized depth-first maze: odd-numbered cells are rooms, carved connections are real 3D corridors.
        boolean[][] seen=new boolean[N][N]; int[] stackX=new int[N*N], stackZ=new int[N*N]; int top=0; stackX[top]=1; stackZ[top++]=1; seen[1][1]=true; solid[1][1]=false;
        while(top>0) {
            int cx=stackX[top-1], cz=stackZ[top-1]; int[] dirs={0,1,2,3};
            for(int a=3;a>0;a--){int b=r.nextInt(a+1),v=dirs[a];dirs[a]=dirs[b];dirs[b]=v;}
            boolean moved=false;
            for(int d:dirs){int nx=cx+(d==0?2:d==1?-2:0), nz=cz+(d==2?2:d==3?-2:0);
                if(nx>0&&nz>0&&nx<N-1&&nz<N-1&&!seen[nx][nz]){seen[nx][nz]=true;solid[nx][nz]=false;solid[(cx+nx)/2][(cz+nz)/2]=false;stackX[top]=nx;stackZ[top++]=nz;moved=true;break;}}
            if(!moved)top--;
        }
        // Open up larger chambers differently on each floor while retaining a navigable maze.
        for(int z=2;z<N-2;z+=6) for(int x=2;x<N-2;x+=6) if(r.nextBoolean()) for(int dz=0;dz<3;dz++)for(int dx=0;dx<3;dx++)solid[x+dx][z+dz]=false;
        solid[1][1]=false; solid[N-2][N-2]=false; solid[N-3][N-2]=false; solid[N-2][N-3]=false;
        // Geometry: tiled floor, solid walls, ceiling slabs, columns and room props.
        for(int z=0;z<N;z++) for(int x=0;x<N;x++) {
            float wx=x*CELL, wz=z*CELL;
            add(floorModel,wx,0,wz,1,1,1);
            if(solid[x][z]) {
                ModelInstance wi=new ModelInstance(wallModel); wi.materials.get(0).set(ColorAttribute.createDiffuse(levelWall)); wi.transform.setToTranslation(wx,1.8f,wz); world.add(wi);
                if((x+z+index)%5==0) { ModelInstance ti=new ModelInstance(trimModel); ti.materials.get(0).set(ColorAttribute.createDiffuse(levelTrim)); ti.transform.setToTranslation(wx,.22f,wz); world.add(ti); }
            } else if(r.nextFloat()<.055f && !(x<4&&z<4) && !(x>N-4&&z>N-4)) {
                float h=.65f+r.nextFloat()*1.7f; add(propModel,wx, h*.5f,wz,1,h/1.2f,1);
            }
        }
        // Ceiling is deliberately segmented; some levels have missing panels.
        for(int z=1;z<N-1;z++) for(int x=1;x<N-1;x++) if(!solid[x][z] && (index==2||index==5||r.nextFloat()>.08f)) {
            add(ceilingModel,x*CELL,3.55f,z*CELL,1,1,1);
            // Repeated recessed fluorescent panels establish the familiar Level 0 ceiling.
            if(index==0 && (x+z)%3==0) add(lightModel,x*CELL,3.43f,z*CELL,1,1,1);
        }
        // Three collectible memory cores are placed on traversable tiles, away from start and exit.
        collected=0; int placed=0, attempts=0;
        while(placed<REQUIRED&&attempts++<3000){int x=2+r.nextInt(N-4),z=2+r.nextInt(N-4); if(!solid[x][z] && (x>4||z>4) && (Math.abs(x-(N-2))+Math.abs(z-(N-2))>3)){
            pickups.add(new Pickup(x*CELL,1.05f,z*CELL)); placed++; solid[x][z]=false;}}
        px=CELL; pz=CELL; yaw=0; pitch=0; stamina=1; fear=0; elapsed=0; damageFlash=0;
        monsterX=(N-2)*CELL; monsterZ=(N-2)*CELL; monsterSpeed=1.45f+index*.10f;
        monsterBodyI=new ModelInstance(monsterBody); monsterHeadI=new ModelInstance(monsterHead); monsterArmLI=new ModelInstance(monsterLimb); monsterArmRI=new ModelInstance(monsterLimb); monsterLegLI=new ModelInstance(monsterLimb); monsterLegRI=new ModelInstance(monsterLimb);
        state=State.PLAYING; updateCamera(0);
    }
    private static class Pickup { float x,y,z; boolean taken=false; Pickup(float x,float y,float z){this.x=x;this.y=y;this.z=z;} }

    private void updateCamera(float dt) {
        float bobY=(Math.abs(joystickX)+Math.abs(joystickY)>.08f)?MathUtils.sin(elapsed*10f)*.045f:0;
        camera.position.set(px,1.68f+bobY,pz);
        float cp=MathUtils.cos(pitch); camera.direction.set(MathUtils.sin(yaw)*cp,MathUtils.sin(pitch),-MathUtils.cos(yaw)*cp).nor(); camera.up.set(Vector3.Y); camera.update();
    }
    private boolean blocked(float x,float z) {
        // Collision matches the actual 3 x 3 wall tiles. The old 1.05-unit
        // padding around every neighboring tile made corridors feel blocked.
        final float radius = .27f;
        int gx=Math.round(x/CELL), gz=Math.round(z/CELL);
        for(int dz=-1;dz<=1;dz++) for(int dx=-1;dx<=1;dx++) {
            int ax=gx+dx, az=gz+dz;
            if(ax<0||az<0||ax>=N||az>=N) return true;
            if(!solid[ax][az]) continue;
            float minX=ax*CELL-CELL*.5f, maxX=ax*CELL+CELL*.5f;
            float minZ=az*CELL-CELL*.5f, maxZ=az*CELL+CELL*.5f;
            float nearestX=MathUtils.clamp(x,minX,maxX);
            float nearestZ=MathUtils.clamp(z,minZ,maxZ);
            float ox=x-nearestX, oz=z-nearestZ;
            if(ox*ox+oz*oz<radius*radius) return true;
        }
        return false;
    }
    private void update(float dt) {
        elapsed+=dt; if(damageFlash>0)damageFlash-=dt;
        if(state!=State.PLAYING)return;
        boolean running=sprint&&stamina>.02f; float speed=running?5.3f:3.1f;
        if(running)stamina=Math.max(0,stamina-dt*.22f);else stamina=Math.min(1,stamina+dt*.12f);
        float forward=-joystickY, strafe=joystickX; if(Gdx.input.isKeyPressed(Input.Keys.W))forward=1;if(Gdx.input.isKeyPressed(Input.Keys.S))forward=-1;if(Gdx.input.isKeyPressed(Input.Keys.A))strafe=-1;if(Gdx.input.isKeyPressed(Input.Keys.D))strafe=1;
        float fx=MathUtils.sin(yaw), fz=-MathUtils.cos(yaw), rx=MathUtils.cos(yaw), rz=MathUtils.sin(yaw);
        float vx=(fx*forward+rx*strafe)*speed*dt, vz=(fz*forward+rz*strafe)*speed*dt;
        if(!blocked(px+vx,pz))px+=vx; if(!blocked(px,pz+vz))pz+=vz;
        if(Math.abs(vx)+Math.abs(vz)>.001f)bob+=dt*speed;
        // The entity hunts through the maze and becomes more aggressive as the player lingers.
        float dx=px-monsterX,dz=pz-monsterZ,dist=(float)Math.sqrt(dx*dx+dz*dz);
        fear=MathUtils.clamp(1f-dist/24f,0,1);
        if(dist<26f){float step=(monsterSpeed+fear*.65f)*dt;float mx=dx/(dist+.001f)*step,mz=dz/(dist+.001f)*step;
            if(!blocked(monsterX+mx,monsterZ))monsterX+=mx;if(!blocked(monsterX,monsterZ+mz))monsterZ+=mz;}
        if(dist<1.65f){state=State.CAUGHT;return;}
        for(Pickup p:pickups)if(!p.taken){float qx=px-p.x,qz=pz-p.z;if(qx*qx+qz*qz<1.8f){p.taken=true;collected++;}}
        if(collected>=REQUIRED && Math.abs(px-(N-2)*CELL)<2.2f && Math.abs(pz-(N-2)*CELL)<2.2f){state=State.COMPLETE;}
        updateCamera(dt); animateMonster();
    }
    private void animateMonster() {
        float phase=elapsed*7f; float bob=MathUtils.sin(phase)*.10f;
        monsterBodyI.transform.setToTranslation(monsterX,1.05f+bob,monsterZ).scale(.8f,1.05f,.55f);
        monsterHeadI.transform.setToTranslation(monsterX,2.0f+bob,monsterZ).scale(.56f,.56f,.56f);
        monsterArmLI.transform.setToTranslation(monsterX-.72f,1.1f+MathUtils.sin(phase)*.24f,monsterZ).scale(.24f,.72f,.24f);
        monsterArmRI.transform.setToTranslation(monsterX+.72f,1.1f-MathUtils.sin(phase)*.24f,monsterZ).scale(.24f,.72f,.24f);
        monsterLegLI.transform.setToTranslation(monsterX-.28f,.38f-MathUtils.sin(phase)*.16f,monsterZ).scale(.26f,.62f,.26f);
        monsterLegRI.transform.setToTranslation(monsterX+.28f,.38f+MathUtils.sin(phase)*.16f,monsterZ).scale(.26f,.62f,.26f);
    }

    @Override public void render() {
        float dt=Math.min(Gdx.graphics.getDeltaTime(),.04f); update(dt);
        Gdx.gl.glViewport(0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        Color clear=levelFloor.cpy().mul(.36f); Gdx.gl.glClearColor(clear.r,clear.g,clear.b,1); Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT|GL20.GL_DEPTH_BUFFER_BIT); Gdx.gl.glEnable(GL20.GL_DEPTH_TEST);
        if(state==State.PLAYING||state==State.PAUSED||state==State.CAUGHT||state==State.COMPLETE){
            modelBatch.begin(camera); for(ModelInstance i:world)modelBatch.render(i,environment);
            for(Pickup p:pickups)if(!p.taken){ModelInstance pi=new ModelInstance(orbModel);pi.transform.setToTranslation(p.x,1.05f+MathUtils.sin(elapsed*2f+p.x)*.13f,p.z).scale(.55f,.55f,.55f);modelBatch.render(pi,environment);}
            modelBatch.render(monsterBodyI,environment);modelBatch.render(monsterHeadI,environment);modelBatch.render(monsterArmLI,environment);modelBatch.render(monsterArmRI,environment);modelBatch.render(monsterLegLI,environment);modelBatch.render(monsterLegRI,environment);
            modelBatch.end();
        }
        drawUI();
    }
    private void drawUI() {
        float w=Gdx.graphics.getWidth(),h=Gdx.graphics.getHeight(); shapes.begin(ShapeRenderer.ShapeType.Filled);
        if(state==State.PLAYING){
            shapes.setColor(.015f,.018f,.016f,.78f);shapes.rect(12,h-72,278,58);shapes.setColor(.68f,.58f,.31f,.85f);shapes.rect(12,h-72,3,58);shapes.setColor(.1f,.1f,.1f,.9f);shapes.rect(22,h-49,112,8);shapes.setColor(.3f,.85f,.55f,1);shapes.rect(22,h-49,112*collected/REQUIRED,8);
            shapes.setColor(.1f,.1f,.1f,.9f);shapes.rect(22,h-65,112,7);shapes.setColor(.9f,.75f,.25f,1);shapes.rect(22,h-65,112*stamina,7);
            // left virtual joystick and right look region
            shapes.setColor(.015f,.02f,.018f,.42f);shapes.circle(105,115,68);shapes.setColor(.72f,.63f,.37f,.28f);shapes.circle(105,115,68);shapes.setColor(.75f,.72f,.62f,.48f);shapes.circle(105+joystickX*32,115-joystickY*32,25);
            shapes.setColor(.015f,.02f,.018f,.32f);shapes.circle(w-105,115,57);shapes.setColor(.72f,.63f,.37f,.20f);shapes.circle(w-105,115,57);
            shapes.setColor(.9f,.9f,.9f,.9f);shapes.rect(w*.5f-1,h*.5f-7,2,14);shapes.rect(w*.5f-7,h*.5f-1,14,2);
            shapes.setColor(.015f,.02f,.018f,.88f);shapes.circle(w-95,112,43);shapes.circle(w-215,112,43);
            shapes.setColor(.68f,.58f,.31f,.92f);shapes.circle(w-95,112,43);shapes.circle(w-215,112,43);
            shapes.setColor(.025f,.03f,.025f,.96f);shapes.circle(w-95,112,39);shapes.circle(w-215,112,39);
            shapes.setColor(.015f,.02f,.018f,.88f);shapes.rect(w-76,h-64,52,46);
            shapes.setColor(.68f,.58f,.31f,.92f);shapes.rect(w-76,h-64,52,3);
        }
        if(damageFlash>0){shapes.setColor(1,.02f,.02f,Math.min(.3f,damageFlash));shapes.rect(0,0,w,h);}
        if(state==State.TITLE||state==State.PAUSED||state==State.CAUGHT||state==State.COMPLETE){shapes.setColor(0,0,0,.76f);shapes.rect(0,0,w,h);}
        shapes.end();
        if(state==State.PLAYING) {
            shapes.begin(ShapeRenderer.ShapeType.Line);
            shapes.setColor(.92f,.86f,.68f,1);
            // Sprint icon: compact forward-moving chevrons.
            shapes.line(w-111,112,w-88,125); shapes.line(w-88,125,w-111,138);
            shapes.line(w-126,112,w-103,125); shapes.line(w-103,125,w-126,138);
            // Flashlight icon: handle and lamp head.
            shapes.line(w-229,96,w-206,128); shapes.line(w-206,128,w-194,120);
            shapes.line(w-194,120,w-217,88); shapes.line(w-217,88,w-229,96);
            shapes.line(w-204,130,w-190,141); shapes.line(w-190,141,w-181,132);
            // Pause icon.
            shapes.line(w-60,h-54,w-60,h-28); shapes.line(w-43,h-54,w-43,h-28);
            shapes.end();
        }
        uiBatch.begin(); font.setColor(Color.WHITE);
        if(state==State.TITLE){font.getData().setScale(2.2f);font.draw(uiBatch,"BACKROOMS: THE DESCENT",w*.12f,h*.72f);font.getData().setScale(1.1f);font.draw(uiBatch,"A LIMINAL HORROR EXPERIENCE",w*.12f,h*.62f);font.draw(uiBatch,"TAP TO ENTER",w*.12f,h*.40f);font.draw(uiBatch,"LEFT: MOVE     RIGHT: LOOK     LOWER-RIGHT: SPRINT",w*.12f,h*.28f);}
        else if(state==State.PLAYING){font.getData().setScale(1f);font.setColor(.88f,.82f,.63f,1);font.draw(uiBatch,levelName,24,h-29);font.setColor(Color.WHITE);font.draw(uiBatch,"CORES  "+collected+" / "+REQUIRED,145,h-56);font.setColor(.88f,.82f,.63f,1);font.draw(uiBatch,"RUN",w-111,54);font.draw(uiBatch,flashlight?"LAMP ON":"LAMP OFF",w-252,54);font.draw(uiBatch,"II",w-59,h-34);font.setColor(Color.WHITE);}
        else if(state==State.PAUSED){font.getData().setScale(2f);font.draw(uiBatch,"PAUSED",w*.43f,h*.65f);font.getData().setScale(1.1f);font.draw(uiBatch,"TAP TO RESUME",w*.40f,h*.47f);font.draw(uiBatch,"LEVEL "+(level+1)+" / 10",w*.43f,h*.36f);}
        else if(state==State.CAUGHT){font.getData().setScale(2.1f);font.draw(uiBatch,"IT FOUND YOU",w*.36f,h*.62f);font.getData().setScale(1.15f);font.draw(uiBatch,"TAP TO RETRY LEVEL",w*.37f,h*.43f);}
        else if(state==State.COMPLETE){font.getData().setScale(2f);font.draw(uiBatch,"LEVEL CLEARED",w*.35f,h*.63f);font.getData().setScale(1.15f);font.draw(uiBatch,level==9?"YOU ESCAPED THE DESCENT":"TAP TO DESCEND",w*.34f,h*.43f);font.draw(uiBatch,"LEVEL "+(level+1)+" / 10",w*.43f,h*.32f);}
        uiBatch.end(); font.getData().setScale(1f);
    }

    @Override public boolean keyDown(int keycode){if(keycode==Input.Keys.ESCAPE||keycode==Input.Keys.BACK){if(state==State.PLAYING)state=State.PAUSED;else if(state==State.PAUSED)state=State.PLAYING;return true;}if(keycode==Input.Keys.SHIFT_LEFT)sprint=true;return false;}
    @Override public boolean keyUp(int keycode){if(keycode==Input.Keys.SHIFT_LEFT)sprint=false;return false;}
    @Override public boolean keyTyped(char c){return false;}
    @Override public boolean touchDown(int screenX,int screenY,int pointer,int button){float y=Gdx.graphics.getHeight()-screenY,w=Gdx.graphics.getWidth(),h=Gdx.graphics.getHeight();
        if(state==State.TITLE){generateLevel(0);return true;}if(state==State.PAUSED){state=State.PLAYING;return true;}if(state==State.CAUGHT){generateLevel(level);return true;}if(state==State.COMPLETE){if(level<9)generateLevel(level+1);else{state=State.TITLE;}return true;}
        if(screenX<w*.42f && y<h*.48f && movePointer==-1){movePointer=pointer;moveOriginX=screenX;moveOriginY=y;joystickX=joystickY=0;return true;}
        if(screenX>w-150 && y<205){sprint=true;sprintPointer=pointer;return true;}
        if(screenX>w-270 && screenX<=w-150 && y<205){flashlight=!flashlight;environment.set(new ColorAttribute(ColorAttribute.AmbientLight, flashlight?.34f:.20f,flashlight?.32f:.19f,flashlight?.25f:.15f,1));return true;}
        if(screenX>w*.78f && y>h*.78f){state=State.PAUSED;return true;}
        if(screenX>w*.48f && lookPointer==-1){lookPointer=pointer;lookLastX=screenX;lookLastY=y;return true;}
        return true;
    }
    @Override public boolean touchUp(int screenX,int screenY,int pointer,int button){if(pointer==movePointer){movePointer=-1;joystickX=joystickY=0;}if(pointer==lookPointer)lookPointer=-1;if(pointer==sprintPointer){sprintPointer=-1;sprint=false;}return true;}
    @Override public boolean touchCancelled(int x,int y,int pointer,int button){return touchUp(x,y,pointer,button);}
    @Override public boolean touchDragged(int screenX,int screenY,int pointer){float y=Gdx.graphics.getHeight()-screenY,w=Gdx.graphics.getWidth();if(pointer==movePointer){joystickX=MathUtils.clamp((screenX-moveOriginX)/54f,-1,1);joystickY=MathUtils.clamp((moveOriginY-y)/54f,-1,1);}else if(pointer==lookPointer){float dx=screenX-lookLastX,dy=y-lookLastY;lookLastX=screenX;lookLastY=y;yaw+=dx*.006f;pitch=MathUtils.clamp(pitch+dy*.004f,-.72f,.72f);updateCamera(0);}return true;}
    @Override public boolean mouseMoved(int x,int y){return false;}
    @Override public boolean scrolled(float amountX,float amountY){return false;}
    @Override public void resize(int width,int height){if(camera!=null){camera.viewportWidth=width;camera.viewportHeight=height;camera.update();}}
    @Override public void pause(){if(state==State.PLAYING)state=State.PAUSED;}
    @Override public void dispose(){if(modelBatch!=null)modelBatch.dispose();if(uiBatch!=null)uiBatch.dispose();if(shapes!=null)shapes.dispose();if(font!=null)font.dispose();for(Model m:models)m.dispose();for(Texture t:textures)t.dispose();}
}

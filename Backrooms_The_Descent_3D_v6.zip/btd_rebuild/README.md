# Backrooms: The Descent — 3D rebuild (v6.0)

This project replaces the previous custom 2.5D raycaster with a polygonal 3D renderer using **libGDX** and Android's OpenGL ES backend.

## Implemented in this build
- Real perspective 3D camera and polygonal world geometry rendered through `ModelBatch`.
- Procedurally generated, traversable maze layouts for ten themed stages.
- 3D floors, walls, ceiling panels, props, collectible memory cores and a multi-part 3D pursuer.
- First-person movement, independent multi-pointer movement/look controls, sprint and stamina.
- Enemy pursuit, collision, collectible objective, exit gate, level progression, pause/retry screens and HUD.
- Landscape Android app, min SDK 23.

## Controls
- Left lower area: movement joystick.
- Right side: drag to look around.
- Lower-right button: sprint while held.
- Upper-right: pause.

## Build
The repository workflow can extract this ZIP and run:

```bash
gradle -p <project-root> --no-daemon :app:assembleDebug
```

Requires JDK 17, Android SDK platform 35, Android Gradle Plugin 8.6.1 and Gradle 8.7.

## Honest limitations
This is now a real 3D libGDX game foundation, not a raycaster. The environments and enemy are procedurally modelled from low-poly geometry; this build does not yet include authored skeletal animations, photorealistic materials, baked lightmaps, advanced physics, voice acting, or a full bespoke map for every stage. Test on a physical Android device; performance and touch feel may need tuning.

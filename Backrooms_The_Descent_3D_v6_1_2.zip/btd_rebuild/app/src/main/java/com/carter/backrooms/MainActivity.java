package com.carter.backrooms;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;

public class MainActivity extends AndroidApplication {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.useAccelerometer = false;
        config.useCompass = false;
        // Avoid requiring WAKE_LOCK permission and avoid multisample EGL config failures
        // on devices whose GLES driver does not expose a compatible 2x MSAA surface.
        config.useWakelock = false;
        config.numSamples = 0;
        try {
            initialize(new DescentGame(), config);
        } catch (Throwable error) {
            Log.e("BackroomsDescent", "Failed to initialize game", error);
            Toast.makeText(this, "Game startup failed. Check Android crash log.", Toast.LENGTH_LONG).show();
            throw error;
        }
    }
}

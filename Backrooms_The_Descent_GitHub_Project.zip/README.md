# Backrooms: The Descent — Android project

A Java/Android first-person pseudo-3D horror prototype designed to build on GitHub Actions. It is intentionally asset-light and does not require Unity or Android Studio on your phone.

## Current implementation
- 10 named levels with distinct wall/floor palettes and procedural maze layouts.
- Ray-cast first-person rendering.
- Mobile joystick movement, right-side look, sprint, interact and flashlight controls.
- Basic pursuing monster AI and proximity/fear feedback.
- Main menu, continue, pause, restart, game-over and completion screens.
- Local save of unlocked/current level and sound/flashlight preferences.
- Basic generated sound cues using Android ToneGenerator (not recorded ambience or full voice/sound design).
- Each level has a carved traversable route to its exit.

## Build on GitHub using only Chrome on Android
1. Sign in or create an account at https://github.com.
2. Tap **+** then **New repository**. Name it `Backrooms-The-Descent`, choose **Public** or **Private**, then create it.
3. On the new repository page, use **Add file → Upload files**.
4. Extract this ZIP on your phone first. Upload the *contents* of the extracted folder (including the hidden `.github` folder). If your mobile browser cannot upload folders, use GitHub's web editor or the GitHub mobile app to add the workflow file at `.github/workflows/android.yml` and upload the remaining project files.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Android APK** if prompted, then choose **Run workflow**. A push to `main` also starts a build automatically.
7. Wait for the run to finish with a green check. Open the completed run, scroll to **Artifacts**, and download `Backrooms-The-Descent-debug-apk`.
8. Extract the artifact ZIP. Install `app-debug.apk`. Android may ask you to allow Chrome or your file manager to install apps from that source. Only allow this for the APK you built from your own repository.

## Technical build
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35; minSdk 23
- Workflow output: `app/build/outputs/apk/debug/app-debug.apk`

## Honest limitations
This is a playable starter build, not a finished commercial-quality game. The monster is currently a simple pursuing silhouette, not a detailed 3D animated creature. Audio is limited to synthesized Android tone cues; it does not yet include recorded ambience, footsteps, creature voice or music. The world is pseudo-3D raycasting, not polygonal 3D. Level designs are original interpretations and not exact fan-wiki recreations. Test on a real device and iterate before wider distribution.

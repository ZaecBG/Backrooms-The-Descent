# Backrooms: The Descent — Android 1.0.0

A landscape, first-person 3D liminal-horror game built with libGDX.

## Release 1.0.0 changes

- Corrected vertical and horizontal touch-look direction.
- Rebuilt wall geometry as full tile-sized solids and replaced oversized proximity collision with a small player-radius / wall-tile collision test.
- Added visible vector-drawn sprint, flashlight, and pause icons to the mobile HUD.
- Added a flashlight toggle that changes the scene's ambient illumination.
- Reworked Level 0's wall/floor/ceiling presentation with faded yellow wallpaper, worn floor tiles, ceiling panels, and fluorescent fixtures.
- Set Android version name to `1.0.0` (version code 10).

## Mobile controls

- Left thumb area: move.
- Right side: look around (drag).
- Bottom-right RUN icon: hold to sprint.
- Bottom-right LAMP icon: toggle ambient illumination.
- Top-right II icon: pause.

## Build

The project uses Java 17, Gradle 8.7, Android Gradle Plugin 8.6.1, and libGDX 1.13.1.

From this directory, run:

```sh
gradle --no-daemon :app:assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Important

This is a first 1.0.0 release candidate source package, not a claim of device-certified or exhaustive QA. Build it with GitHub Actions and test the APK on the target phone. The game currently uses procedural level generation and procedural textures; it does not claim bespoke hand-authored maps, voice acting, or a complete commercial-grade audio/lighting pipeline.

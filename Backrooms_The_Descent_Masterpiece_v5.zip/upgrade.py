from PIL import Image, ImageDraw, ImageFilter
import random, math, os, wave, struct
root='/mnt/data/btd_master/app/src/main/assets'
os.makedirs(root,exist_ok=True)
# 10 distinct, seamless-ish procedural wall materials with layered visual detail
palettes=[((198,177,105),(224,207,143)),((102,119,111),(144,160,150)),((112,86,67),(156,126,101)),((62,79,87),(105,126,132)),((172,155,119),(211,195,157)),((67,55,49),(112,91,77)),((35,40,48),(76,84,94)),((65,105,117),(112,153,161)),((103,101,89),(151,146,128)),((92,102,128),(142,151,173))]
for idx,(base,hi) in enumerate(palettes):
    random.seed(900+idx); im=Image.new('RGB',(512,512),base); d=ImageDraw.Draw(im,'RGBA')
    # mottled paper/concrete noise
    pix=im.load()
    for y in range(512):
      for x in range(512):
        n=random.gauss(0,7+idx%3)
        pix[x,y]=tuple(max(0,min(255,int(c+n))) for c in base)
    d=ImageDraw.Draw(im,'RGBA')
    if idx in (0,4): # wallpaper seams and subtle floral motifs
      for x in range(0,512,128): d.line((x,0,x,512),fill=(65,50,25,65),width=2)
      for y in range(0,512,128): d.line((0,y,512,y),fill=(255,235,170,25),width=1)
      for y in range(35,512,64):
       for x in range(35,512,64):
        d.ellipse((x-5,y-8,x+5,y+8),outline=(*hi,38),width=2); d.ellipse((x-9,y-3,x+9,y+3),outline=(*hi,25),width=1)
    elif idx in (2,3,5):
      for y in range(0,512,64):
       d.line((0,y,512,y),fill=(0,0,0,55),width=3)
       for x in range(random.randint(-40,30),512,96): d.line((x,y,x,y+64),fill=(0,0,0,40),width=2)
      for _ in range(150):
       x=random.randrange(512);y=random.randrange(512);d.line((x,y,x+random.randint(-12,12),y+random.randint(3,30)),fill=(0,0,0,random.randrange(15,55)),width=1)
    elif idx==6:
      for _ in range(350):
       x=random.randrange(512);y=random.randrange(512);r=random.randrange(1,5);d.ellipse((x-r,y-r,x+r,y+r),fill=(180,190,205,random.randrange(8,35)))
    else:
      for y in range(0,512,96): d.line((0,y,512,y),fill=(0,0,0,28),width=2)
      for _ in range(120):
       x=random.randrange(512);y=random.randrange(512);d.line((x,y,x+random.randrange(-20,20),y+random.randrange(2,18)),fill=(0,0,0,22),width=1)
    im=im.filter(ImageFilter.GaussianBlur(0.35))
    im.save(f'{root}/wall_{idx}.jpg',quality=88,optimize=True)
# 10 ambience beds: layered low drones + level-specific hum/water/wind textures
sr=22050; dur=12
for idx in range(10):
    random.seed(100+idx); path=f'{root}/ambience_{idx}.wav'
    phases=[random.random()*math.tau for _ in range(8)]
    freqs=[42+idx*2,55+idx*1.3,73+idx*1.8,91+idx,117+idx*2,146+idx,183+idx,220+idx*2]
    with wave.open(path,'wb') as wf:
      wf.setnchannels(1);wf.setsampwidth(2);wf.setframerate(sr)
      frames=[]
      for n in range(sr*dur):
        t=n/sr
        v=sum(math.sin(math.tau*f*t+p)*a for f,p,a in zip(freqs,phases,[.10,.07,.045,.025,.018,.012,.009,.006]))
        # slow amplitude swells and filtered noise for environmental movement
        swell=.72+.28*math.sin(math.tau*t/(5.2+idx*.23))
        noise=(random.random()*2-1)*(.018 if idx not in (6,7) else .035)
        if idx in (3,6): v+=.025*math.sin(math.tau*(700+80*math.sin(t*.4))*t)
        if idx==7: v+=.035*math.sin(math.tau*31*t)*math.sin(math.tau*.17*t)
        sample=max(-1,min(1,(v*swell+noise)*.55))
        frames.append(struct.pack('<h',int(sample*32767)))
      wf.writeframes(b''.join(frames))

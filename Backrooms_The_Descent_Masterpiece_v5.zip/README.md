# Backrooms: The Descent — Enhanced Android build

A landscape, first-person mobile liminal-horror game prototype built with native Android Java.

## Included in this build
- Ten themed levels with seeded layouts and level-specific wall materials.
- Ten original generated ambient audio loops, one per level.
- Textured ray-cast walls rather than flat colour columns.
- Mobile multitouch movement/look controls, sprint, flashlight and interaction.
- Keycard and battery objectives, stamina, battery drain, enemy pursuit and saved progress.
- Android Gradle build workflow.

## Build
Open this repository in GitHub and run **Actions → Build Android APK**. The workflow uploads `app-debug.apk` as an artifact.

## Controls
- Left side: hold and drag to move.
- Right side: drag to look around.
- Hold Sprint to run; use Interact near pickups and exits.
- Flashlight button toggles the light; pause button opens pause menu.

## Honest scope
This is an expanded 2.5D ray-cast game, not a full polygonal 3D engine. The wall textures and ambient loops are original procedural assets; the monster is still a stylized billboard rather than a rigged animated 3D character. It should be tested on a real Android device after building.

package com.carter.backrooms;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class GameView extends View {
    private static final int MENU=0, PLAY=1, PAUSE=2, CAUGHT=3, COMPLETE=4;
    private static final int SIZE=20;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private final ToneGenerator tones;
    private final Bitmap[] wallTextures = new Bitmap[10];
    private MediaPlayer ambience;
    private final Random random = new Random();
    private final String[] names = {
        "LEVEL 0 - THE LOBBY", "LEVEL 1 - HABITABLE ZONE", "LEVEL 2 - PIPE DREAMS",
        "LEVEL 3 - ELECTRICAL STATION", "LEVEL 4 - ABANDONED OFFICE",
        "LEVEL 5 - TERROR HOTEL", "LEVEL 6 - LIGHTS OUT", "LEVEL 7 - THALASSOPHOBIA",
        "LEVEL 8 - CAVE SYSTEM", "LEVEL 9 - THE END"
    };
    private final int[] walls = {
        0xffc8b66f,0xff82928a,0xff9a8068,0xff65777c,0xffb0a17e,
        0xff594b43,0xff363c43,0xff516c78,0xff6e6b60,0xff858b9b
    };
    private final int[] floors = {
        0xff71613d,0xff53635b,0xff655347,0xff343f43,0xff766c58,
        0xff352e2c,0xff20242a,0xff314d58,0xff46453f,0xff444b5a
    };
    private int[][] map = new int[SIZE][SIZE];
    private int state = MENU, level = 0, savedLevel = 0;
    private double x=2.5, y=2.5, angle=0;
    private double joyX=0, joyY=0;
    private double monsterX=14.5, monsterY=14.5;
    private float w,h, density;
    // Track each finger independently so movement, camera look and sprint can run together.
    private int joystickPointerId=-1, lookPointerId=-1, sprintPointerId=-1;
    private float lookLastX=-1;
    private float joyBaseX=105, joyBaseY=0;
    private int keyX=9, keyY=2;
    private boolean hasKey=false;
    private int batteryX=5, batteryY=2;
    private boolean batteryFound=false;
    private float battery=1.0f;
    private boolean sprint=false, flashlight=true, soundOn=true;
    private boolean monsterAwake=false;
    private long last=0, levelStart=0, caughtUntil=0;
    private long lastStepSound=0, lastHeartbeat=0, lastPathUpdate=0;
    private double monsterTargetX=-1, monsterTargetY=-1;
    private float stamina=1f, fear=0f;
    private String message="Find the exit. Avoid what follows.";
    private int exitX=SIZE-3, exitY=SIZE-3;

    public GameView(Context c) {
        super(c);
        density=getResources().getDisplayMetrics().density;
        prefs=c.getSharedPreferences("descent_save", Context.MODE_PRIVATE);
        tones=new ToneGenerator(AudioManager.STREAM_MUSIC, 55);
        for(int i=0;i<10;i++){ try { wallTextures[i]=BitmapFactory.decodeStream(c.getAssets().open("wall_"+i+".jpg")); } catch(Exception ignored) {} }
        savedLevel=Math.max(0,Math.min(9,prefs.getInt("level",0)));
        soundOn=prefs.getBoolean("sound",true);
        flashlight=prefs.getBoolean("flashlight",true);
        setFocusable(true);
        makeLevel(0);
    }

    public void pauseForLifecycle() { if(state==PLAY) state=PAUSE; stopAmbience(); }
    public void resumeForLifecycle() { if(state==PLAY) startAmbience(); invalidate(); }

    private void startAmbience(){
        stopAmbience(); if(!soundOn) return;
        try { AssetFileDescriptor afd=getContext().getAssets().openFd("ambience_"+level+".wav"); ambience=new MediaPlayer(); ambience.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength()); afd.close(); ambience.setLooping(true); ambience.setVolume(0.38f,0.38f); ambience.prepare(); ambience.start(); } catch(Exception ignored) { stopAmbience(); }
    }
    private void stopAmbience(){ if(ambience!=null){try{ambience.stop();}catch(Exception ignored){} ambience.release(); ambience=null;} }

    private void beep(int tone, int duration) {
        if(soundOn) tones.startTone(tone,duration);
    }

    private void makeLevel(int n) {
        level=n; map=new int[SIZE][SIZE];
        Random r=new Random(7123L+n*98317L);
        for(int yy=0;yy<SIZE;yy++) for(int xx=0;xx<SIZE;xx++)
            map[yy][xx]=(xx==0||yy==0||xx==SIZE-1||yy==SIZE-1)?1:0;

        // Level-specific obstacle patterns, with a carved guaranteed path.
        double chance=0.13+n*0.014;
        for(int yy=2;yy<SIZE-2;yy++) for(int xx=2;xx<SIZE-2;xx++) {
            if((xx==2&&yy==2)||(xx==exitX&&yy==exitY)) continue;
            if(r.nextDouble()<chance) map[yy][xx]=1;
        }
        int cx=2,cy=2;
        while(cx<exitX){map[cy][cx]=0;cx++;}
        while(cy<exitY){map[cy][cx]=0;cy++;}
        map[exitY][exitX]=2;

        // Additional connected side passages and occasional rooms.
        for(int k=0;k<4+n/2;k++){
            int rx=3+r.nextInt(13), ry=3+r.nextInt(13);
            for(int yy=Math.max(2,ry-1);yy<=Math.min(SIZE-3,ry+1);yy++)
                for(int xx=Math.max(2,rx-1);xx<=Math.min(SIZE-3,rx+1);xx++)
                    if(r.nextFloat()<0.7f) map[yy][xx]=0;
        }
        // Re-carve the route after room generation.
        cx=2;cy=2;
        while(cx<exitX){map[cy][cx]=0;cx++;}
        while(cy<exitY){map[cy][cx]=0;cy++;}
        map[exitY][exitX]=2;

        x=2.5;y=2.5;angle=0;
        keyX=9; keyY=2; hasKey=false; map[keyY][keyX]=0;
        batteryX=5; batteryY=2; batteryFound=false; battery=0.72f; map[batteryY][batteryX]=0;
        monsterX=exitX+0.5; monsterY=exitY-2.5;
        monsterTargetX=monsterTargetY=-1; lastPathUpdate=0;
        monsterAwake=false; stamina=1; fear=0; sprint=false;
        levelStart=System.currentTimeMillis();
        message=level==0?"Find the keycard. Then reach the exit.":"Find the access key. Something is nearby.";
        startAmbience();
        prefs.edit().putInt("level",level).apply();
        beep(ToneGenerator.TONE_PROP_ACK,100);
    }

    private int tile(int tx,int ty) {
        if(tx<0||ty<0||tx>=SIZE||ty>=SIZE)return 1;
        return map[ty][tx];
    }
    private boolean solid(double xx,double yy){return tile((int)xx,(int)yy)==1;}
    private double clamp(double v,double a,double b){return Math.max(a,Math.min(b,v));}

    private void tick(double dt) {
        if(state!=PLAY)return;
        double moveSpeed=(sprint&&stamina>0.02?3.0:1.85);
        if(flashlight && battery>0){ battery=Math.max(0,battery-(float)dt*0.0105f); if(battery<=0){flashlight=false;message="Flashlight battery depleted. Find a spare cell.";} }
        if(sprint && (Math.abs(joyX)+Math.abs(joyY)>0.1)) stamina=Math.max(0,stamina-(float)dt*0.23f);
        else stamina=Math.min(1,stamina+(float)dt*0.12f);
        double f=joyY*moveSpeed*dt, side=joyX*moveSpeed*dt;
        double dx=Math.cos(angle)*f-Math.sin(angle)*side;
        double dy=Math.sin(angle)*f+Math.cos(angle)*side;
        if(!solid(x+dx,y))x+=dx;
        if(!solid(x,y+dy))y+=dy;

        double distance=Math.hypot(monsterX-x,monsterY-y);
        if(distance<8.0) monsterAwake=true;
        if(monsterAwake) {
            long nowMs=System.currentTimeMillis();
            if(nowMs-lastPathUpdate>420){ updateMonsterPath(); lastPathUpdate=nowMs; }
            double speed=(level==6?1.0:0.78)+(level*0.025);
            double tx=monsterTargetX<0?x:monsterTargetX, ty=monsterTargetY<0?y:monsterTargetY;
            double a=Math.atan2(ty-monsterY,tx-monsterX);
            double mx=Math.cos(a)*speed*dt, my=Math.sin(a)*speed*dt;
            if(!solid(monsterX+mx,monsterY))monsterX+=mx;
            if(!solid(monsterX,monsterY+my))monsterY+=my;
            fear=(float)clamp((8.0-distance)/8.0,0,1);
            if(distance<0.72) {
                state=CAUGHT; caughtUntil=System.currentTimeMillis()+1800;
                beep(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,500);
                return;
            }
            if(distance<5 && System.currentTimeMillis()-lastHeartbeat>950) {
                beep(ToneGenerator.TONE_PROP_BEEP2,100); lastHeartbeat=System.currentTimeMillis();
            }
        }
        if(Math.hypot(x-(exitX+0.5),y-(exitY+0.5))<1.15) message="Exit nearby — tap INTERACT";
        if(System.currentTimeMillis()-lastStepSound>420 && Math.abs(joyX)+Math.abs(joyY)>0.2) {
            beep(ToneGenerator.TONE_PROP_BEEP,45); lastStepSound=System.currentTimeMillis();
        }
    }

    private void updateMonsterPath(){
        int sx=(int)monsterX, sy=(int)monsterY, gx=(int)x, gy=(int)y;
        if(sx==gx&&sy==gy){monsterTargetX=x;monsterTargetY=y;return;}
        if(sx<0||sy<0||gx<0||gy<0||sx>=SIZE||sy>=SIZE||gx>=SIZE||gy>=SIZE)return;
        int[][] px=new int[SIZE][SIZE], py=new int[SIZE][SIZE];
        boolean[][] seen=new boolean[SIZE][SIZE];
        int[] qx=new int[SIZE*SIZE], qy=new int[SIZE*SIZE]; int head=0,tail=0;
        qx[tail]=sx; qy[tail++]=sy; seen[sy][sx]=true;
        int[] ox={1,-1,0,0}, oy={0,0,1,-1};
        while(head<tail){
            int cx=qx[head],cy=qy[head++]; if(cx==gx&&cy==gy)break;
            for(int d=0;d<4;d++){int nx=cx+ox[d],ny=cy+oy[d];
                if(nx<1||ny<1||nx>=SIZE-1||ny>=SIZE-1||seen[ny][nx]||tile(nx,ny)==1)continue;
                seen[ny][nx]=true;px[ny][nx]=cx;py[ny][nx]=cy;qx[tail]=nx;qy[tail++]=ny;
            }
        }
        if(!seen[gy][gx]){monsterTargetX=x;monsterTargetY=y;return;}
        int cx=gx,cy=gy;
        while(px[cy][cx]!=sx||py[cy][cx]!=sy){int nx=px[cy][cx],ny=py[cy][cx];cx=nx;cy=ny;if(cx==sx&&cy==sy)break;}
        monsterTargetX=cx+0.5; monsterTargetY=cy+0.5;
    }

    private boolean monsterVisible(double delta,double distance){
        if(Math.abs(delta)>0.55||distance>12)return false;
        int steps=(int)(distance*8);
        for(int i=1;i<steps;i++){double t=i/(double)steps;
            if(tile((int)(x+(monsterX-x)*t),(int)(y+(monsterY-y)*t))==1)return false;
        }
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); w=getWidth();h=getHeight();
        if(w<=0||h<=0)return;
        long now=System.nanoTime();
        double dt=last==0?0.016:Math.min(0.05,(now-last)/1e9);last=now;
        if(state==PLAY)tick(dt);
        drawScene(c);
        if(state==MENU)drawMenu(c);
        else if(state==PAUSE)drawPause(c);
        else if(state==CAUGHT)drawCaught(c);
        else if(state==COMPLETE)drawComplete(c);
        else drawHud(c);
        postInvalidateDelayed(16);
    }

    private int shade(int color,double f){
        f=clamp(f,0,1);
        return Color.rgb((int)(Color.red(color)*f),(int)(Color.green(color)*f),(int)(Color.blue(color)*f));
    }

    private void drawScene(Canvas c) {
        int rays=Math.max(160,(int)(w/3));
        float sw=w/rays;
        double fov=Math.toRadians(66);
        for(int i=0;i<rays;i++){
            double cam=2.0*i/rays-1.0;
            double ra=angle+Math.atan(cam*Math.tan(fov/2));
            double rx=Math.cos(ra),ry=Math.sin(ra);
            int mx=(int)x,my=(int)y,stepX,stepY,hit=0,side=0;
            double ddx=Math.abs(1/(Math.abs(rx)<0.00001?0.00001:rx));
            double ddy=Math.abs(1/(Math.abs(ry)<0.00001?0.00001:ry));
            double sx,sy;
            if(rx<0){stepX=-1;sx=(x-mx)*ddx;}else{stepX=1;sx=(mx+1-x)*ddx;}
            if(ry<0){stepY=-1;sy=(y-my)*ddy;}else{stepY=1;sy=(my+1-y)*ddy;}
            double dist=0;
            for(int j=0;j<60;j++){
                if(sx<sy){sx+=ddx;mx+=stepX;dist=sx-ddx;side=0;}
                else{sy+=ddy;my+=stepY;dist=sy-ddy;side=1;}
                hit=tile(mx,my);if(hit!=0)break;
            }
            double rawDist=Math.max(0.08,dist);
            double wallPos=(side==0?y+rawDist*ry:x+rawDist*rx);
            double wallU=wallPos-Math.floor(wallPos);
            if((side==0&&rx>0)||(side==1&&ry<0)) wallU=1-wallU;
            dist=Math.max(0.08,dist*Math.cos(ra-angle));
            float wh=(float)Math.min(h*1.4,h/dist),top=(h-wh)/2,bottom=top+wh;
            double light=Math.max(0.16,1-dist/(level==6?8.5:15.0));
            if(!flashlight)light*=0.55;
            p.setColor(shade(0xff242321,light*0.9));c.drawRect(i*sw,0,(i+1)*sw+1,h/2,p);
            p.setColor(shade(floors[level],light));c.drawRect(i*sw,h/2,(i+1)*sw+1,h,p);
            if(hit!=0){
                int col=hit==2?0xff37c9a0:shade(walls[level],light*(side==1?0.78:1));
                if(hit==1 && wallTextures[level]!=null){
                    Bitmap tex=wallTextures[level]; int tx=Math.max(0,Math.min(tex.getWidth()-1,(int)(wallU*tex.getWidth())));
                    p.setAlpha((int)(255*clamp(light*(side==1?0.78:1),0.12,1)));
                    c.drawBitmap(tex,new android.graphics.Rect(tx,0,tx+1,tex.getHeight()),new RectF(i*sw,top,(i+1)*sw+1,bottom),p); p.setAlpha(255);
                    // Subtle depth/edge shading preserves the moody ray-cast look.
                    p.setColor(0x18000000); c.drawRect(i*sw,top,(i+1)*sw+1,bottom,p);
                } else { p.setColor(col);c.drawRect(i*sw,top,(i+1)*sw+1,bottom,p); }
                if(hit==2){p.setColor(0x887effd8);c.drawRect(i*sw+sw*.2f,top+wh*.12f,(i+1)*sw-sw*.2f,bottom-wh*.12f,p);}
                else if(wh>30 && ((i/3)%7==0)){p.setColor(0x22000000);c.drawRect(i*sw,top,i*sw+2,bottom,p);}
            }
        }

        // Draw a looming monster silhouette when visible in the forward cone.
        double ma=Math.atan2(monsterY-y,monsterX-x);
        double delta=Math.atan2(Math.sin(ma-angle),Math.cos(ma-angle));
        double md=Math.hypot(monsterX-x,monsterY-y);
        if(monsterVisible(delta,md)) {
            float sx=(float)(w/2+(delta/Math.toRadians(66))*w);
            float size=(float)(h/(md*0.85));
            float base=h/2+size*.48f;
            p.setColor(0xff101012);
            c.drawOval(sx-size*.22f,base-size*.95f,sx+size*.22f,base-size*.15f,p);
            c.drawRoundRect(sx-size*.32f,base-size*.2f,sx+size*.32f,base+size*.55f,size*.16f,size*.16f,p);
            p.setColor(0xffb52b24);
            c.drawCircle(sx-size*.09f,base-size*.67f,Math.max(1,size*.025f),p);
            c.drawCircle(sx+size*.09f,base-size*.67f,Math.max(1,size*.025f),p);
        }

        // Keycard pickup: a floating golden marker rendered as a simple billboard.
        if(!hasKey) {
            double ka=Math.atan2(keyY+0.5-y,keyX+0.5-x);
            double kd=Math.hypot(keyX+0.5-x,keyY+0.5-y);
            double kdelta=Math.atan2(Math.sin(ka-angle),Math.cos(ka-angle));
            if(Math.abs(kdelta)<0.62 && kd<11) {
                float kx=(float)(w/2+(kdelta/Math.toRadians(66))*w);
                float ks=(float)Math.max(5,Math.min(h*0.18,h/(kd*2.8)));
                float ky=h*0.52f;
                p.setColor(0xffffd15a);
                c.drawRoundRect(kx-ks*.55f,ky-ks*.22f,kx+ks*.55f,ky+ks*.22f,ks*.12f,ks*.12f,p);
                p.setColor(0xff8b5a20);
                c.drawCircle(kx+ks*.28f,ky,ks*.08f,p);
            }
        }

        // Spare battery pickup: bright green cell marker.
        if(!batteryFound) {
            double ba=Math.atan2(batteryY+0.5-y,batteryX+0.5-x);
            double bd=Math.hypot(batteryX+0.5-x,batteryY+0.5-y);
            double bdelta=Math.atan2(Math.sin(ba-angle),Math.cos(ba-angle));
            if(Math.abs(bdelta)<0.62 && bd<11) {
                float bx=(float)(w/2+(bdelta/Math.toRadians(66))*w);
                float bs=(float)Math.max(5,Math.min(h*0.14,h/(bd*3.1)));
                float by=h*0.59f;
                p.setColor(0xff62e6a1);
                c.drawRoundRect(bx-bs*.34f,by-bs*.48f,bx+bs*.34f,by+bs*.48f,bs*.10f,bs*.10f,p);
                p.setColor(0xffd8ffe8);c.drawRect(bx-bs*.13f,by-bs*.25f,bx+bs*.13f,by+bs*.25f,p);
            }
        }

        // Flashlight cone overlay and vignette.
        if(flashlight){p.setColor(0x0cfff4cf);c.drawRect(0,0,w,h,p);}
        p.setColor(0x30000000);c.drawRect(0,0,w,8*density,p);c.drawRect(0,h-8*density,w,h,p);
        p.setColor(0x22ff0000);c.drawRect(0,0,w* fear,h,p);
        p.setColor(0xaaffffff);float cx=w/2,cy=h/2;
        c.drawLine(cx-5*density,cy,cx+5*density,cy,p);
        c.drawLine(cx,cy-5*density,cx,cy+5*density,p);
    }

    private void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setColor(color);p.setTextSize(size*density);p.setFakeBoldText(bold);p.setTextAlign(Paint.Align.LEFT);c.drawText(s,x,y,p);p.setFakeBoldText(false);
    }
    private void panel(Canvas c,float l,float t,float r,float b,int color){
        p.setColor(color);c.drawRoundRect(new RectF(l,t,r,b),12*density,12*density,p);
    }
    private void button(Canvas c,String label,float l,float t,float r,float b,int color){
        panel(c,l,t,r,b,color);p.setColor(Color.WHITE);p.setTextSize(13*density);p.setFakeBoldText(true);p.setTextAlign(Paint.Align.CENTER);
        c.drawText(label,(l+r)/2,(t+b)/2+5*density,p);p.setTextAlign(Paint.Align.LEFT);p.setFakeBoldText(false);
    }

    private void drawHud(Canvas c){
        panel(c,12*density,10*density,245*density,72*density,0xaa000000);
        text(c,"LEVEL "+(level+1)+" / 10",24*density,34*density,15,Color.WHITE,true);
        text(c,names[level],24*density,55*density,10,0xffe0d7bd,false);
        panel(c,260*density,12*density,w-12*density,48*density,0x99000000);
        text(c,message,273*density,35*density,11,Color.WHITE,false);
        text(c,hasKey?"ACCESS KEY: FOUND":"ACCESS KEY: MISSING",w-300*density,128*density,9,hasKey?0xff8be4b9:0xffffd15a,true);
        text(c,batteryFound?"SPARE CELL: FOUND":"SPARE CELL: SEARCHING",w-300*density,143*density,8,0xffa9e8c4,true);
        // stamina bar
        panel(c,14*density,h-20*density,150*density,h-12*density,0x99000000);
        p.setColor(0xffd5b45c);c.drawRect(15*density,h-19*density,(15+134*stamina)*density,h-13*density,p);
        // joystick
        float jx=(joystickPointerId==-1?105*density:joyBaseX),jy=(joystickPointerId==-1?h-105*density:joyBaseY);
        p.setColor(0x55333333);c.drawCircle(jx,jy,66*density,p);
        p.setColor(0x99ffffff);c.drawCircle(jx+(float)joyX*30*density,jy-(float)joyY*30*density,24*density,p);
        panel(c,w-300*density, h-18*density,w-166*density,h-10*density,0x99000000);
        p.setColor(0xff62e6a1);c.drawRect(w-299*density,h-17*density,w-(299-132*battery)*density,h-11*density,p);
        text(c,"CELL",w-298*density,h-24*density,8,0xffd9f5e5,true);
        button(c,sprint?"SPRINTING":"SPRINT",w-300*density,h-91*density,w-166*density,h-25*density,0xaa69552b);
        button(c,"INTERACT",w-154*density,h-91*density,w-16*density,h-25*density,0xaa176d55);
        button(c,flashlight?"LIGHT ON":"LIGHT OFF",w-154*density,62*density,w-16*density,108*density,0xaa333d4a);
        button(c,"||",w-58*density,12*density,w-12*density,54*density,0xaa000000);
    }

    private void drawMenu(Canvas c){
        c.drawColor(0xff171713);
        text(c,"BACKROOMS",w*.08f,h*.25f,32,0xffd9c77d,true);
        text(c,"THE DESCENT",w*.08f,h*.25f+30*density,17,Color.WHITE,true);
        text(c,"A LIMINAL HORROR EXPERIENCE",w*.08f,h*.25f+58*density,10,0xffb8b39e,false);
        button(c,"NEW GAME",w*.08f,h*.57f,w*.48f,h*.57f+55*density,0xff78643b);
        button(c,"CONTINUE  (LEVEL "+(savedLevel+1)+")",w*.52f,h*.57f,w*.92f,h*.57f+55*density,0xff46574e);
        button(c,"SOUND: "+(soundOn?"ON":"OFF"),w*.08f,h*.57f+68*density,w*.48f,h*.57f+112*density,0xff343434);
        button(c,"FLASHLIGHT: "+(flashlight?"ON":"OFF"),w*.52f,h*.57f+68*density,w*.92f,h*.57f+112*density,0xff343434);
        text(c,"LEFT THUMB: MOVE     RIGHT THUMB: LOOK     HOLD SPRINT TO RUN",w*.08f,h*.88f,10,0xffaaa99e,false);
        text(c,"Find the access key and a spare battery. The exit is never safe while it follows.",w*.08f,h*.93f,9,0xff858477,false);
    }
    private void drawPause(Canvas c){
        p.setColor(0xbb000000);c.drawRect(0,0,w,h,p);
        text(c,"PAUSED",w*.40f,h*.32f,28,Color.WHITE,true);
        button(c,"RESUME",w*.35f,h*.48f,w*.65f,h*.48f+48*density,0xff536c5d);
        button(c,"RESTART LEVEL",w*.35f,h*.48f+58*density,w*.65f,h*.48f+106*density,0xff66543a);
        button(c,"MAIN MENU",w*.35f,h*.48f+116*density,w*.65f,h*.48f+164*density,0xff444444);
    }
    private void drawCaught(Canvas c){
        p.setColor(0xff160909);c.drawRect(0,0,w,h,p);
        text(c,"FOUND YOU",w*.38f,h*.43f,30,0xffe34c40,true);
        text(c,"Tap to try this level again",w*.34f,h*.53f,14,Color.WHITE,false);
    }
    private void drawComplete(Canvas c){
        p.setColor(0xff101b18);c.drawRect(0,0,w,h,p);
        text(c,"YOU ESCAPED",w*.34f,h*.40f,30,0xff8be4b9,true);
        text(c,"You survived all ten levels.",w*.34f,h*.50f,14,Color.WHITE,false);
        button(c,"PLAY AGAIN",w*.38f,h*.62f,w*.62f,h*.62f+48*density,0xff286d53);
    }

    private void interact(){
        if(state!=PLAY)return;
        if(!batteryFound && Math.hypot(x-(batteryX+.5),y-(batteryY+.5))<1.35){
            batteryFound=true; battery=Math.min(1.0f,battery+0.55f); message="Spare cell collected. Flashlight recharged.";
            beep(ToneGenerator.TONE_PROP_ACK,150); return;
        }
        if(!hasKey && Math.hypot(x-(keyX+.5),y-(keyY+.5))<1.35){
            hasKey=true; message="Keycard acquired. Find the exit.";
            beep(ToneGenerator.TONE_PROP_ACK,180); return;
        }
        if(Math.hypot(x-(exitX+.5),y-(exitY+.5))<1.45){
            if(!hasKey){message="ACCESS DENIED — find the keycard first.";beep(ToneGenerator.TONE_PROP_NACK,180);return;}
            if(level==9){state=COMPLETE;stopAmbience();prefs.edit().putInt("level",0).apply();}
            else {savedLevel=level+1;makeLevel(level+1);}
        } else {message="Search the rooms for the access key.";}
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        int action=e.getActionMasked();
        int index=e.getActionIndex();
        int pointerId=e.getPointerId(index);

        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN){
            float tx=e.getX(index), ty=e.getY(index);
            if(state==MENU){
                if(ty>h*.55f&&ty<h*.55f+65*density){
                    if(tx<w*.5f){savedLevel=0;makeLevel(0);state=PLAY;}
                    else{makeLevel(savedLevel);state=PLAY;}
                } else if(ty>=h*.55f+65*density&&ty<h*.55f+125*density){
                    if(tx<w*.5f){soundOn=!soundOn;prefs.edit().putBoolean("sound",soundOn).apply(); if(state==PLAY){if(soundOn)startAmbience();else stopAmbience();}}
                    else{flashlight=!flashlight;prefs.edit().putBoolean("flashlight",flashlight).apply();}
                }
                invalidate(); return true;
            }
            if(state==PAUSE){
                if(ty>h*.48f&&ty<h*.48f+54*density)state=PLAY;
                else if(ty>h*.48f+56*density&&ty<h*.48f+110*density)makeLevel(level);
                else if(ty>h*.48f+112*density&&ty<h*.48f+170*density)state=MENU;
                invalidate(); return true;
            }
            if(state==CAUGHT){makeLevel(level);state=PLAY;invalidate();return true;}
            if(state==COMPLETE){savedLevel=0;makeLevel(0);state=PLAY;invalidate();return true;}
            if(state==PLAY){
                if(tx>w-65*density&&ty<60*density){state=PAUSE;invalidate();return true;}
                if(tx>w-165*density&&ty>h-115*density){interact();invalidate();return true;}
                if(tx>w-165*density&&ty<120*density){flashlight=!flashlight;prefs.edit().putBoolean("flashlight",flashlight).apply();invalidate();return true;}
                if(tx>w-310*density&&tx<w-165*density&&ty>h-115*density){sprintPointerId=pointerId;sprint=true;return true;}
                if(tx<w*.43f && joystickPointerId==-1){joystickPointerId=pointerId;joyBaseX=tx;joyBaseY=ty;updateJoy(tx,ty);}
                else if(tx>=w*.43f && lookPointerId==-1){lookPointerId=pointerId;lookLastX=tx;}
                return true;
            }
        } else if(action==MotionEvent.ACTION_MOVE && state==PLAY){
            if(joystickPointerId!=-1){int i=e.findPointerIndex(joystickPointerId);if(i>=0)updateJoy(e.getX(i),e.getY(i));}
            if(lookPointerId!=-1){int i=e.findPointerIndex(lookPointerId);if(i>=0){float nx=e.getX(i);if(lookLastX>=0)angle+=(nx-lookLastX)*0.0080;lookLastX=nx;}}
            return true;
        } else if(action==MotionEvent.ACTION_POINTER_UP || action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL){
            if(pointerId==joystickPointerId){joystickPointerId=-1;joyX=joyY=0;}
            if(pointerId==lookPointerId){lookPointerId=-1;lookLastX=-1;}
            if(pointerId==sprintPointerId){sprintPointerId=-1;sprint=false;}
            if(action==MotionEvent.ACTION_CANCEL || action==MotionEvent.ACTION_UP){
                joystickPointerId=lookPointerId=sprintPointerId=-1;
                joyX=joyY=0;sprint=false;lookLastX=-1;
            }
            return true;
        }
        return true;
    }

    public void shutdown(){stopAmbience();try{tones.release();}catch(Exception ignored){}}

    private void updateJoy(float tx,float ty){
        double dx=(tx-joyBaseX)/(66*density);
        double dy=(joyBaseY-ty)/(66*density);
        double len=Math.hypot(dx,dy);
        if(len>1){dx/=len;dy/=len;}
        joyX=dx;joyY=dy;
    }
}
